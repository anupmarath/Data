const { app } = require('@azure/functions');
const CryptoJS = require("crypto-js");

app.http('Gen_Key', {
    methods: ['GET', 'POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log(`Http function processed request for url "${request.url}"`);
       
        const secret = '90f86a56b454cf6890ba7cf4ee1d138b7bef492be3310ad7bfb47115c5c2434a';
      //  const url= 'https://app.enqlare.com/rest/api/v1/Status?Date=2023-01-28&Page=0';

        var signBytes = CryptoJS.HmacSHA256(request.url, secret);
        var signHex = CryptoJS.enc.Hex.stringify(signBytes);
        
        return { body: signHex };

    }
});
